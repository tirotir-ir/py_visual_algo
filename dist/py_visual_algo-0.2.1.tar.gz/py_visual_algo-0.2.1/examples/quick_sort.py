from py_visual_algo.algorithms.sorting import quick_sort

data = [10, 4, 6, 3, 8]
print("Original Data:", data)

sorted_data = quick_sort(data)
print("Sorted Data:", sorted_data)
