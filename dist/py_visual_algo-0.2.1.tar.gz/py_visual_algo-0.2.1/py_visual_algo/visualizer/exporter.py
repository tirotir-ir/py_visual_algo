def export_visualization(data, filename):
    """Export visualization to a file."""
