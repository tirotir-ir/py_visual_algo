THEMES = {"dark": {}, "light": {}}
