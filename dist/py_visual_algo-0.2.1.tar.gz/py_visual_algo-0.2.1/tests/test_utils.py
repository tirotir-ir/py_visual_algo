def test_validate_data():
    """Test Data Validation."""
