def test_bubble_sort():
    """Test Bubble Sort."""
