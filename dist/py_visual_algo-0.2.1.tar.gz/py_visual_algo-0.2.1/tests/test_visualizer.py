def test_plot_sorting():
    """Test Sorting Plot."""
