from py_visual_algo.algorithms.sorting import merge_sort

data = [9, 7, 5, 3, 1]
print("Original Data:", data)

sorted_data = merge_sort(data)
print("Sorted Data:", sorted_data)
