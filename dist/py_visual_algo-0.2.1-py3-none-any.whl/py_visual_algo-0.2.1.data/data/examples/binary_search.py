from py_visual_algo.algorithms.searching import binary_search

data = [1, 3, 5, 7, 9, 11, 13]
target = 7
result = binary_search(data, target)
print(f"Binary Search: Target {target} found at index {result}")
