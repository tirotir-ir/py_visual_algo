def test_cli():
    """Test Command Line Interface."""
