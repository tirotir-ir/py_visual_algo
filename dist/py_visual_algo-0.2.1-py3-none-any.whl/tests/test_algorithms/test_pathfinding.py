def test_dijkstra():
    """Test Dijkstra's Algorithm."""
