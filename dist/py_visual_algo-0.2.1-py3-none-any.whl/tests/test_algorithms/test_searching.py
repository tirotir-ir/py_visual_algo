def test_binary_search():
    """Test Binary Search."""
