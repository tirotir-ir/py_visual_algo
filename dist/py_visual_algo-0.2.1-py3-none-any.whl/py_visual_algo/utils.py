def validate_data(data):
    """Utility function to validate input data."""
